def readinput(s):
    return [[int(x) for x in row.split()] for row in s]

def eachlinesum(s) -> int:
    return sum(max(row) - min(row) for row in s)

# Testing with the provided samples
test_cases = [["5 1 9 5", "7 5 3", "2 4 6 8"],["5 5", "7 5 1", "2 4 6 8 10"],["1 5 10", "2 4 6"]]
results = [eachlinesum(readinput(case)) for case in test_cases]
for case, result in zip(test_cases, results):
    print(f"Checksum({case}) = {result}")

# Generating test cases
from TestCaseHandler import TestCaseHandler
test_cases = [["3 2 1 3", "4 5 6", "1 2 3 4"],["1", "2 2 2", "3 4 6 8"],["1 1", "2 3 4 5 6"], ["1 2 3 4 5", "2 3 4 5 6", "3 4 5 6 7"]]
results = [eachlinesum(readinput(case)) for case in test_cases]
handler = TestCaseHandler(5, test_cases, results)
handler.write_to_files()